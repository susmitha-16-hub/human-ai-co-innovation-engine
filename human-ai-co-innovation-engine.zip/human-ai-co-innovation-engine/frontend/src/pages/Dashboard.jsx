export default function Dashboard() {
  return (
    <div style={{ color: "#fff" }}>
      <h1>HUMAN_AI_CO_INNOVATION_ENGINE</h1>
      <p>Speak or type an idea and analyze risks instantly.</p>
      <p>MOVE TO THE RISK ANALYSIS TO SEE RESULTS</p>
    </div>
  );
}
